import React from 'react';

const App = () => {
  return <div className='overflow-hidden'>react app</div>;
};

export default App;
