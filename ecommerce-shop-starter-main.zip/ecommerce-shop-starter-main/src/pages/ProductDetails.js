import React from 'react';

const ProductDetails = () => {
  return <div>Product Details Page</div>;
};

export default ProductDetails;
