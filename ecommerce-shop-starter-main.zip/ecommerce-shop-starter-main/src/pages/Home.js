import React from 'react';

const Home = () => {
  return <div>Homepage</div>;
};

export default Home;
