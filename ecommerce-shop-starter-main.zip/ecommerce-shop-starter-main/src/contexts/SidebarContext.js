import React from 'react';

const SidebarContext = () => {
  return <div>SidebarContext</div>;
};

export default SidebarContext;
