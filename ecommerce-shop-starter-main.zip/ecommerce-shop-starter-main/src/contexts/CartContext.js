import React from 'react';

const CartContext = () => {
  return <div>CartContext</div>;
};

export default CartContext;
