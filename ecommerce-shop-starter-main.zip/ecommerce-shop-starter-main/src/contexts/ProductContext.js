import React from 'react';

const ProductContext = () => {
  return <div>ProductContext</div>;
};

export default ProductContext;
